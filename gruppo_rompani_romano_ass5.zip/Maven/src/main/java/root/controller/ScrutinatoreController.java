package root.controller;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import root.*;
import root.util.Scheda;
import root.util.Scrutinatore;

public class ScrutinatoreController extends Controller {
    
    @FXML
    private VBox parent;
	
	@Override
    public void init() {

    }

    @FXML
    void onActionCrea() {
    	
    }

}
