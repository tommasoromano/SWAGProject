package root.controller;

public abstract class Controller {

	public Controller() {
		// TODO Auto-generated constructor stub
	}
	
	public void init() {
		
	}
	
	public void init(Object param) {
		
	}

}

