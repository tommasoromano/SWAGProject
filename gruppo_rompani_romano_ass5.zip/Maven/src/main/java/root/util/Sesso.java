package root.util;

public enum Sesso {
	M,
	F
}
