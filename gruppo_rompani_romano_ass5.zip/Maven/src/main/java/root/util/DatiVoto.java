package root.util;

public class DatiVoto {

	private String data;
	
	public DatiVoto(String data) {
		this.data = data;
	}
	
	@Override
	public String toString() { return this.data; }

}
